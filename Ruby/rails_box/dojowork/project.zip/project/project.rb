class Project
  attr_accessor :name, :description, :owner, :task
  def initialize name, description, owner, task
    @name = name
    @description = description
    @owner = owner
    @task = task
  end
  def elevator_pitch
    "#{@name}, #{@description}"
  end
end